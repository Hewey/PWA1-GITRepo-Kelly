/**
 * Created by the JavaScript Development Team
 * Class: PWA
 * Goal: Goal7
 */

// an array with 5 names
// create a for loop that creates 3 objects stored in an array and when initiating make sure to choose a random person
// a function that displays the names on a webpage but does not allow the same name to appear twice
// create an interval that calls the function above that calls it every 30 seconds
// run a function that updates each of the people
