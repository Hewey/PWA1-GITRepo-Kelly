/**
 * Created by the JavaScript Development Team
 * Class: PWA
 * Goal: Goal7
 */
// add the object containing the people to the global object 
// create two variables that hold jobs an actions and are on the object hold the people 